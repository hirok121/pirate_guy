<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="fg_objects" tilewidth="58" tileheight="44" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="42" height="44" source="../../Assets/7-Objects/fg_objects/Barrel.png"/>
 </tile>
 <tile id="1">
  <image width="58" height="42" source="../../Assets/7-Objects/fg_objects/crate.png"/>
 </tile>
</tileset>
