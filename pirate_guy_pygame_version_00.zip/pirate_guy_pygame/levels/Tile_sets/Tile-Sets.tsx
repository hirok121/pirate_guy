<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Tile-Sets" tilewidth="64" tileheight="64" tilecount="30" columns="6">
 <image source="../../Assets/8-Tile-Sets/Tile-Sets.png" width="384" height="320"/>
</tileset>
