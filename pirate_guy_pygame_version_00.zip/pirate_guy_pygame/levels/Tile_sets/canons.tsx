<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="canons" tilewidth="62" tileheight="46" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="62" height="46" source="../../Assets/7-Objects/16-Enemy-Cannon/canon_filp.png"/>
 </tile>
 <tile id="1">
  <image width="62" height="46" source="../../Assets/7-Objects/16-Enemy-Cannon/canon.png"/>
 </tile>
</tileset>
