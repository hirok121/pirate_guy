<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="bg_objects" tilewidth="80" tileheight="61" tilecount="9" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="14" height="32" source="../../Assets/7-Objects/bg_objects/1.png"/>
 </tile>
 <tile id="1">
  <image width="16" height="21" source="../../Assets/7-Objects/bg_objects/Blue Bottle.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="56" source="../../Assets/7-Objects/bg_objects/Chair.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="56" source="../../Assets/7-Objects/bg_objects/Chair_flip.png"/>
 </tile>
 <tile id="4">
  <image width="14" height="24" source="../../Assets/7-Objects/bg_objects/Green Bottle.png"/>
 </tile>
 <tile id="5">
  <image width="16" height="31" source="../../Assets/7-Objects/bg_objects/Red Bottle.png"/>
 </tile>
 <tile id="6">
  <image width="19" height="14" source="../../Assets/7-Objects/bg_objects/Skull.png"/>
 </tile>
 <tile id="7">
  <image width="80" height="32" source="../../Assets/7-Objects/bg_objects/Table.png"/>
 </tile>
 <tile id="8">
  <image width="58" height="61" source="../../Assets/7-Objects/bg_objects/Windows.png"/>
 </tile>
</tileset>
