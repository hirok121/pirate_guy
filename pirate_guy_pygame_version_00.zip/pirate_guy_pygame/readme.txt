Made by Hirok reza
First complete 2D platformer game by pygame module
Project duration 1 week
Completed April 9 , 2023
version 00

Note that : Game must be run from "pirate_guy_pygame/code" directory